
public class Main {
    public static void main(String[] args) {
        C obj = new C(10, "Hello", 3.14f);


        obj.readX();
        obj.readY();
        obj.readS();

        obj.displayX();
        obj.displayXYS();
    }
}