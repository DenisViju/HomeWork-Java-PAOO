import java.util.Scanner;

public class B extends A {
    public String s;

    public B(int x, String s) {
        super(x);
        this.s = s;
    }

    public void readS() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introdu valoarea lui s: ");
        this.s = scanner.nextLine();
    }

    @Override
    public void displayX() {
        System.out.println("Valoarea lui x din B este: " + x);
    }
}