public class A {
    public int x;

    public A(int x) {
        this.x = x;
    }

    public int getX() {
        return x;
    }

    public void displayX() {
        System.out.println("Valoarea lui x este: " + x);
    }
}