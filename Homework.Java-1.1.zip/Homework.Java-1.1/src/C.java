import java.util.Scanner;

public class C extends B {
    public float y;

    public C(int x, String s, float y) {
        super(x, s);
        this.y = y;
    }

    public void readY() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introdu valoarea lui y: ");
        String input = scanner.nextLine();
        this.y = Float.parseFloat(input);
    }

    public void readX() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introdu valoarea lui x: ");
        this.x = scanner.nextInt();
        scanner.nextLine();
    }

    public void displayXYS() {
        System.out.println("x: " + x + ", y: " + y + ", s: " + s);
    }
}